#include <iostream>
using namespace std;

// Node.h
class Node {
public:
    int data;
    Node* next;

    Node(int value = 0);  // Constructor with default value
};

